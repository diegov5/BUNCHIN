# BUNCHIN'

This is the Github Repository for the CPSC 224 Gonzaga class in the Spring 2018 Semester.
Members of this group are Diego Valdez, Thomas McDonald, and David Ihle
