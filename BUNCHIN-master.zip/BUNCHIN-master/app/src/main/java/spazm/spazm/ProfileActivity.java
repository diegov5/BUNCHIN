package spazm.spazm;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Diego Valdez Local on 4/5/2018.
 */

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}
